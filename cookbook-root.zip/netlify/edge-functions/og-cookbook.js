export default async function handler(request, context) {
  const url = new URL(request.url);
  const id = url.searchParams.get('id');

  if (!id) return context.next();

  const SUPABASE_URL = Deno.env.get('SUPABASE_URL');
  const SUPABASE_KEY = Deno.env.get('SUPABASE_SERVICE_KEY') || Deno.env.get('SUPABASE_KEY');

  let cookbook = null;
  let senderName = '';

  try {
    const res = await fetch(
      `${SUPABASE_URL}/rest/v1/shared_recipes?id=eq.${id}&limit=1`,
      {
        headers: {
          apikey: SUPABASE_KEY,
          Authorization: `Bearer ${SUPABASE_KEY}`,
        },
      }
    );
    const rows = await res.json();
    if (rows && rows[0]) {
      cookbook = rows[0].cookbook || rows[0].recipe || {};
      senderName = rows[0].sender_name || '';
    }
  } catch (e) {
    return context.next();
  }

  if (!cookbook) return context.next();

  const DOMAIN = 'https://clickpickandcook.com';
  const name = cookbook.name || 'A shared cookbook';
  const recipes = cookbook.recipes || [];
  const count = recipes.length;
  const cuisines = [...new Set(recipes.map(r => r.cuisine).filter(Boolean))].slice(0, 3).join(', ');

  const pageTitle = senderName
    ? `${senderName} shared a cookbook: ${name}`
    : `${name} — Click Pick & Cook`;

  const description = count
    ? `${count} recipe${count !== 1 ? 's' : ''}${cuisines ? ' · ' + cuisines : ''} — browse and save your favorites.`
    : 'A curated recipe collection — browse and save your favorites.';

  const ogTags = `
  <meta name="description" content="${escHtml(description)}">
  <meta property="og:type" content="website">
  <meta property="og:url" content="${DOMAIN}/shared-cookbook.html?id=${id}">
  <meta property="og:title" content="${escHtml(pageTitle)}">
  <meta property="og:description" content="${escHtml(description)}">
  <meta property="og:image" content="${DOMAIN}/og-image.png">
  <meta property="og:image:width" content="1200">
  <meta property="og:image:height" content="630">
  <meta property="og:site_name" content="Click Pick &amp; Cook">
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:title" content="${escHtml(pageTitle)}">
  <meta name="twitter:description" content="${escHtml(description)}">
  <meta name="twitter:image" content="${DOMAIN}/og-image.png">
  <title>${escHtml(pageTitle)}</title>`;

  const response = await context.next();
  const html = await response.text();

  const patched = html
    .replace(/<title>[^<]*<\/title>/, '')
    .replace(/<meta name="description"[^>]*>/, '')
    .replace(/<meta property="og:[^>]*>/g, '')
    .replace(/<meta name="twitter:[^>]*>/g, '')
    .replace('</head>', ogTags + '\n</head>');

  return new Response(patched, {
    headers: { 'content-type': 'text/html; charset=utf-8' },
  });
}

function escHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/"/g, '&quot;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

export const config = { path: '/shared-cookbook.html' };
