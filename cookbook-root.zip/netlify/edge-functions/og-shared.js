export default async function handler(request, context) {
  const url = new URL(request.url);
  const id = url.searchParams.get('id');

  // No id — serve the page as-is
  if (!id) return context.next();

  const SUPABASE_URL = Deno.env.get('SUPABASE_URL');
  const SUPABASE_KEY = Deno.env.get('SUPABASE_SERVICE_KEY') || Deno.env.get('SUPABASE_KEY');

  let recipe = null;
  let senderName = '';

  try {
    const res = await fetch(
      `${SUPABASE_URL}/rest/v1/shared_recipes?id=eq.${id}&limit=1`,
      {
        headers: {
          apikey: SUPABASE_KEY,
          Authorization: `Bearer ${SUPABASE_KEY}`,
        },
      }
    );
    const rows = await res.json();
    if (rows && rows[0]) {
      recipe = rows[0].recipe || {};
      senderName = rows[0].sender_name || '';
    }
  } catch (e) {
    // Fall through to generic page
    return context.next();
  }

  if (!recipe || !recipe.title) return context.next();

  // Build dynamic meta values
  const title = recipe.title || 'A shared recipe';
  const cuisine = recipe.cuisine || '';
  const mealType = recipe.mealType || '';
  const time = recipe.time || '';
  const difficulty = recipe.difficulty || '';
  const description = recipe.description
    ? recipe.description.slice(0, 160)
    : `${[cuisine, mealType, time, difficulty].filter(Boolean).join(' · ')} — open to view full recipe and instructions.`;

  const DOMAIN = 'https://clickpickandcook.com';

  // Use recipe photo if it's a real URL (not base64)
  const photo = recipe.sharedPhotos && recipe.sharedPhotos[0]
    ? recipe.sharedPhotos[0]
    : (recipe._cloudPhotos && recipe._cloudPhotos[0])
    ? recipe._cloudPhotos[0]
    : null;
  const ogImage = (photo && photo.startsWith('http'))
    ? photo
    : `${DOMAIN}/og-image.png`;

  const pageTitle = senderName
    ? `${senderName} shared a recipe: ${title}`
    : `${title} — Click Pick & Cook`;

  const ogTags = `
  <meta name="description" content="${escHtml(description)}">
  <meta property="og:type" content="article">
  <meta property="og:url" content="${DOMAIN}/shared.html?id=${id}">
  <meta property="og:title" content="${escHtml(pageTitle)}">
  <meta property="og:description" content="${escHtml(description)}">
  <meta property="og:image" content="${ogImage}">
  <meta property="og:image:width" content="1200">
  <meta property="og:image:height" content="630">
  <meta property="og:site_name" content="Click Pick &amp; Cook">
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:title" content="${escHtml(pageTitle)}">
  <meta name="twitter:description" content="${escHtml(description)}">
  <meta name="twitter:image" content="${ogImage}">
  <title>${escHtml(pageTitle)}</title>`;

  // Fetch the original HTML and inject tags
  const response = await context.next();
  const html = await response.text();

  // Replace static OG block and title
  const patched = html
    .replace(/<title>[^<]*<\/title>/, '')
    .replace(/<meta name="description"[^>]*>/, '')
    .replace(/<meta property="og:[^>]*>/g, '')
    .replace(/<meta name="twitter:[^>]*>/g, '')
    .replace('</head>', ogTags + '\n</head>');

  return new Response(patched, {
    headers: { 'content-type': 'text/html; charset=utf-8' },
  });
}

function escHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/"/g, '&quot;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

export const config = { path: '/shared.html' };
