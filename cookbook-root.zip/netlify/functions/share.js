const SUPABASE_URL = process.env.SUPABASE_URL;
const SUPABASE_KEY = process.env.SUPABASE_SERVICE_KEY || process.env.SUPABASE_KEY;

async function supabase(method, path, body) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1${path}`, {
    method,
    headers: {
      "Content-Type": "application/json",
      "apikey": SUPABASE_KEY,
      "Authorization": `Bearer ${SUPABASE_KEY}`,
      "Prefer": method === "POST" ? "return=representation" : ""
    },
    body: body ? JSON.stringify(body) : undefined
  });
  const text = await res.text();
  console.log(`Supabase ${method} ${path} → ${res.status}: ${text.slice(0,300)}`);
  try { return { status: res.status, data: JSON.parse(text) }; }
  catch(e) { return { status: res.status, data: text }; }
}

function makeId() {
  return Math.random().toString(36).substr(2,5) + Date.now().toString(36).substr(-4);
}

exports.handler = async function (event) {
  const headers = { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" };

  if (event.httpMethod === "OPTIONS") return { statusCode: 200, headers };
  if (!SUPABASE_URL || !SUPABASE_KEY) {
    return { statusCode: 500, headers, body: JSON.stringify({ error: "SUPABASE_URL or SUPABASE_SERVICE_KEY not set." }) };
  }

  try {
    if (event.httpMethod === "POST") {
      const body = JSON.parse(event.body);
      const recipe = body.recipe || {};
      console.log('Sharing recipe:', recipe.title);
      console.log('sharedPhotos:', JSON.stringify(recipe.sharedPhotos));
      console.log('photo:', recipe.photo ? recipe.photo.slice(0,80) : 'none');

      const id = makeId();
      const row = {
        id,
        recipe: body.recipe,
        background_id: body.backgroundId || "parchment",
        message: body.message || "",
        sender_name: body.senderName || "",
        created_at: new Date().toISOString()
      };
      const result = await supabase("POST", "/shared_recipes", row);
      if (result.status >= 400) {
        throw new Error(`Supabase error ${result.status}: ${JSON.stringify(result.data)}`);
      }
      const siteUrl = body.siteUrl || "https://celadon-duckanoo-753d58.netlify.app";
      return { statusCode: 200, headers, body: JSON.stringify({ url: `${siteUrl}/shared.html?id=${id}` }) };
    }

    if (event.httpMethod === "GET") {
      const id = event.queryStringParameters && event.queryStringParameters.id;
      if (!id) return { statusCode: 400, headers, body: JSON.stringify({ error: "Missing id" }) };
      const result = await supabase("GET", `/shared_recipes?id=eq.${id}&limit=1`);
      if (result.status >= 400) throw new Error(`Supabase error ${result.status}: ${JSON.stringify(result.data)}`);
      const rows = Array.isArray(result.data) ? result.data : [];
      if (!rows.length) return { statusCode: 404, headers, body: JSON.stringify({ error: "Recipe not found." }) };
      const row = rows[0];
      const recipe = row.recipe || {};
      console.log('Loading recipe:', recipe.title, '| sharedPhotos:', JSON.stringify(recipe.sharedPhotos), '| photo:', recipe.photo ? recipe.photo.slice(0,80) : 'none');
      return { statusCode: 200, headers, body: JSON.stringify({
        recipe: row.recipe,
        backgroundId: row.background_id,
        message: row.message,
        senderName: row.sender_name
      })};
    }

    return { statusCode: 405, headers, body: JSON.stringify({ error: "Method not allowed" }) };
  } catch (e) {
    console.error("share error:", e.message);
    return { statusCode: 500, headers, body: JSON.stringify({ error: e.message }) };
  }
};
