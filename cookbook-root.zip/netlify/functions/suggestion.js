const SUPABASE_URL = process.env.SUPABASE_URL;
const SUPABASE_KEY = process.env.SUPABASE_SERVICE_KEY;

const headers = {
  'Content-Type': 'application/json',
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS'
};

exports.handler = async function(event) {
  if (event.httpMethod === 'OPTIONS') return { statusCode: 200, headers, body: '' };
  const qs = event.queryStringParameters || {};

  // GET: fetch single suggestion by ID
  if (event.httpMethod === 'GET' && qs.id) {
    const res = await fetch(`${SUPABASE_URL}/rest/v1/suggestions?id=eq.${encodeURIComponent(qs.id)}&select=*`, {
      headers: { 'apikey': SUPABASE_KEY, 'Authorization': `Bearer ${SUPABASE_KEY}` }
    });
    const rows = await res.json();
    if (!rows.length) return { statusCode: 404, headers, body: JSON.stringify({ error: 'Not found' }) };
    return { statusCode: 200, headers, body: JSON.stringify({ suggestion: rows[0].data }) };
  }

  // GET: match suggestions by ingredient words and/or coupon IDs
  if (event.httpMethod === 'GET' && qs.match) {
    const ingWords = (qs.ingredients || '').toLowerCase();
    const couponIds = (qs.coupons || '').split(',').filter(Boolean);

    // Fetch all active suggestions
    const res = await fetch(`${SUPABASE_URL}/rest/v1/suggestions?select=*&active=eq.true`, {
      headers: { 'apikey': SUPABASE_KEY, 'Authorization': `Bearer ${SUPABASE_KEY}` }
    });
    const rows = await res.json();
    if (!Array.isArray(rows)) return { statusCode: 200, headers, body: JSON.stringify({ suggestions: [] }) };

    const matched = rows.filter(function(row) {
      const s = row.data;
      if (s.triggerType === 'ingredient') {
        return ingWords.includes((s.triggerValue || '').toLowerCase());
      }
      if (s.triggerType === 'coupon') {
        return couponIds.includes(s.triggerValue);
      }
      if (s.triggerType === 'broadcast') return true;
      return false;
    }).map(function(row) { return row.data; });

    return { statusCode: 200, headers, body: JSON.stringify({ suggestions: matched }) };
  }

  // POST: create a suggestion
  if (event.httpMethod === 'POST') {
    const body = JSON.parse(event.body || '{}');
    const s = body.suggestion;
    if (!s || !s.recipe) return { statusCode: 400, headers, body: JSON.stringify({ error: 'No suggestion data' }) };

    if (!s.id) s.id = 'sg_' + Date.now() + Math.random().toString(36).slice(2, 8);

    const res = await fetch(`${SUPABASE_URL}/rest/v1/suggestions`, {
      method: 'POST',
      headers: {
        'apikey': SUPABASE_KEY,
        'Authorization': `Bearer ${SUPABASE_KEY}`,
        'Content-Type': 'application/json',
        'Prefer': 'return=representation'
      },
      body: JSON.stringify({ id: s.id, data: s, active: true })
    });

    if (!res.ok) {
      const err = await res.text();
      return { statusCode: 500, headers, body: JSON.stringify({ error: err }) };
    }

    const SITE = process.env.URL || 'https://celadon-duckanoo-753d58.netlify.app';
    return {
      statusCode: 200, headers,
      body: JSON.stringify({
        suggestion: s,
        url: `${SITE}/?suggest=${s.id}`
      })
    };
  }

  return { statusCode: 405, headers, body: JSON.stringify({ error: 'Method not allowed' }) };
};
