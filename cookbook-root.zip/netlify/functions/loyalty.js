/**
 * Loyalty Segment API
 *
 * Store side (they call this):
 *   POST /loyalty  { action: "push", segments: [{phone_hash, tags: ["chicken","pasta"]}] }
 *   Header: x-api-key: <store_api_key>
 *
 * App side (we call this):
 *   POST /loyalty  { action: "match", phone_hash }
 *   Returns: { segments: ["chicken","pasta"], storeId, storeName }
 *
 * Admin (generate store API keys):
 *   POST /loyalty  { action: "create_store", storeName, adminSecret }
 *   Returns: { storeId, apiKey }
 *
 * Data model in Supabase:
 *   loyalty_stores  (id, name, api_key_hash, created_at)
 *   loyalty_segments (phone_hash, store_id, tags[], updated_at)
 *   -- phone_hash is SHA-256 of the customer's phone number
 *   -- store hashes before sending, we never see raw phone numbers
 */

const crypto = require('crypto');
const SUPABASE_URL = process.env.SUPABASE_URL;
const SUPABASE_KEY = process.env.SUPABASE_SERVICE_KEY;
const ADMIN_SECRET = process.env.LOYALTY_ADMIN_SECRET || 'change-me-in-netlify-env';

const headers = {
  'Content-Type': 'application/json',
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, x-api-key'
};

async function supabase(path, method, body) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${path}`, {
    method: method || 'GET',
    headers: {
      'apikey': SUPABASE_KEY,
      'Authorization': `Bearer ${SUPABASE_KEY}`,
      'Content-Type': 'application/json',
      'Prefer': 'return=representation'
    },
    body: body ? JSON.stringify(body) : undefined
  });
  const text = await res.text();
  try { return { ok: res.ok, status: res.status, data: JSON.parse(text) }; }
  catch(e) { return { ok: res.ok, status: res.status, data: text }; }
}

function hashKey(key) {
  return crypto.createHash('sha256').update(key).digest('hex');
}

exports.handler = async function(event) {
  if (event.httpMethod === 'OPTIONS') return { statusCode: 200, headers, body: '' };
  if (event.httpMethod !== 'POST') return { statusCode: 405, headers, body: JSON.stringify({ error: 'POST only' }) };

  let body;
  try { body = JSON.parse(event.body || '{}'); }
  catch(e) { return { statusCode: 400, headers, body: JSON.stringify({ error: 'Invalid JSON' }) }; }

  const { action } = body;

  // ── CREATE STORE (admin only) ────────────────────────────────
  if (action === 'create_store') {
    if (body.adminSecret !== ADMIN_SECRET) {
      return { statusCode: 401, headers, body: JSON.stringify({ error: 'Unauthorized' }) };
    }
    const { storeName } = body;
    if (!storeName) return { statusCode: 400, headers, body: JSON.stringify({ error: 'storeName required' }) };

    const apiKey = 'rvl_' + crypto.randomBytes(24).toString('hex');
    const storeId = 'st_' + Date.now() + crypto.randomBytes(4).toString('hex');

    const r = await supabase('loyalty_stores', 'POST', {
      id: storeId,
      name: storeName,
      api_key_hash: hashKey(apiKey)
    });

    if (!r.ok) return { statusCode: 500, headers, body: JSON.stringify({ error: 'Failed to create store', detail: r.data }) };

    return { statusCode: 200, headers, body: JSON.stringify({
      storeId,
      storeName,
      apiKey, // shown ONCE — store must save it
      note: 'Save this API key — it will not be shown again.'
    })};
  }

  // ── PUSH SEGMENTS (store → us) ───────────────────────────────
  if (action === 'push') {
    const apiKey = event.headers['x-api-key'] || event.headers['X-Api-Key'];
    if (!apiKey) return { statusCode: 401, headers, body: JSON.stringify({ error: 'Missing x-api-key header' }) };

    // Look up store by hashed key
    const keyHash = hashKey(apiKey);
    const storeRes = await supabase(`loyalty_stores?api_key_hash=eq.${keyHash}&select=id,name`);
    if (!storeRes.ok || !storeRes.data.length) {
      return { statusCode: 401, headers, body: JSON.stringify({ error: 'Invalid API key' }) };
    }
    const store = storeRes.data[0];

    const { segments } = body;
    if (!Array.isArray(segments) || !segments.length) {
      return { statusCode: 400, headers, body: JSON.stringify({ error: 'segments array required' }) };
    }

    // Validate — each segment must have phone_hash and tags
    const valid = segments.filter(function(s) {
      return s.phone_hash && typeof s.phone_hash === 'string'
        && Array.isArray(s.tags) && s.tags.length;
    });

    if (!valid.length) {
      return { statusCode: 400, headers, body: JSON.stringify({ error: 'No valid segments. Each needs phone_hash (string) and tags (array).' }) };
    }

    // Upsert segments — overwrite existing for this store+phone_hash
    let upserted = 0;
    for (const seg of valid) {
      const r = await supabase('loyalty_segments', 'POST', {
        phone_hash: seg.phone_hash,
        store_id: store.id,
        store_name: store.name,
        tags: seg.tags,
        updated_at: new Date().toISOString()
      });
      // If conflict (duplicate), patch instead
      if (!r.ok && r.status === 409) {
        await supabase(
          `loyalty_segments?phone_hash=eq.${seg.phone_hash}&store_id=eq.${store.id}`,
          'PATCH',
          { tags: seg.tags, updated_at: new Date().toISOString() }
        );
      }
      upserted++;
    }

    return { statusCode: 200, headers, body: JSON.stringify({
      ok: true,
      storeId: store.id,
      storeName: store.name,
      upserted
    })};
  }

  // ── MATCH (app → us, customer opens app) ────────────────────
  if (action === 'match') {
    const { phone_hash } = body;
    if (!phone_hash) return { statusCode: 400, headers, body: JSON.stringify({ error: 'phone_hash required' }) };

    const r = await supabase(`loyalty_segments?phone_hash=eq.${encodeURIComponent(phone_hash)}&select=store_id,store_name,tags`);
    if (!r.ok) return { statusCode: 500, headers, body: JSON.stringify({ error: 'Lookup failed' }) };

    // Flatten all tags across all stores for this customer
    const allTags = [];
    const stores = [];
    (r.data || []).forEach(function(row) {
      (row.tags || []).forEach(function(t) { if (!allTags.includes(t)) allTags.push(t); });
      if (!stores.find(function(s){ return s.id === row.store_id; })) {
        stores.push({ id: row.store_id, name: row.store_name });
      }
    });

    return { statusCode: 200, headers, body: JSON.stringify({
      matched: allTags.length > 0,
      tags: allTags,
      stores
    })};
  }

  return { statusCode: 400, headers, body: JSON.stringify({ error: 'Unknown action' }) };
};
