const SUPABASE_URL = process.env.SUPABASE_URL;
const SUPABASE_KEY = process.env.SUPABASE_SERVICE_KEY;

exports.handler = async function(event) {
  const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS'
  };
  if (event.httpMethod === 'OPTIONS') return { statusCode: 200, headers, body: '' };

  // GET: retrieve coupon by ID
  if (event.httpMethod === 'GET') {
    const id = new URLSearchParams(event.rawQuery || event.queryStringParameters ? 
      Object.entries(event.queryStringParameters||{}).map(([k,v])=>k+'='+v).join('&') : '').get('id')
      || (event.queryStringParameters && event.queryStringParameters.id);
    if (!id) return { statusCode: 400, headers, body: JSON.stringify({ error: 'No ID' }) };

    const res = await fetch(`${SUPABASE_URL}/rest/v1/coupons?id=eq.${encodeURIComponent(id)}&select=*`, {
      headers: { 'apikey': SUPABASE_KEY, 'Authorization': `Bearer ${SUPABASE_KEY}` }
    });
    const rows = await res.json();
    if (!rows.length) return { statusCode: 404, headers, body: JSON.stringify({ error: 'Coupon not found' }) };
    return { statusCode: 200, headers, body: JSON.stringify({ coupon: rows[0].data }) };
  }

  // POST: create/store a coupon
  if (event.httpMethod === 'POST') {
    const body = JSON.parse(event.body || '{}');
    const coupon = body.coupon;
    if (!coupon) return { statusCode: 400, headers, body: JSON.stringify({ error: 'No coupon data' }) };

    // Generate ID if not present
    if (!coupon.id) coupon.id = 'cp_' + Date.now() + Math.random().toString(36).slice(2,8);
    // Generate scannable code if not present
    if (!coupon.code) coupon.code = coupon.id.toUpperCase().replace('CP_','');

    const res = await fetch(`${SUPABASE_URL}/rest/v1/coupons`, {
      method: 'POST',
      headers: {
        'apikey': SUPABASE_KEY,
        'Authorization': `Bearer ${SUPABASE_KEY}`,
        'Content-Type': 'application/json',
        'Prefer': 'return=representation'
      },
      body: JSON.stringify({ id: coupon.id, data: coupon })
    });

    if (!res.ok) {
      const err = await res.text();
      return { statusCode: 500, headers, body: JSON.stringify({ error: err }) };
    }

    const SITE = process.env.URL || 'https://celadon-duckanoo-753d58.netlify.app';
    return {
      statusCode: 200, headers,
      body: JSON.stringify({
        coupon,
        url: `${SITE}/?coupon=${coupon.id}`
      })
    };
  }

  return { statusCode: 405, headers, body: JSON.stringify({ error: 'Method not allowed' }) };
};
