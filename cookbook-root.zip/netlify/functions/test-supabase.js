const SUPABASE_URL = process.env.SUPABASE_URL;
const SUPABASE_KEY = process.env.SUPABASE_KEY;

exports.handler = async function(event) {
  const headers = { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" };
  
  if (!SUPABASE_URL || !SUPABASE_KEY) {
    return { statusCode: 200, headers, body: JSON.stringify({ 
      error: "Missing env vars", 
      hasUrl: !!SUPABASE_URL, 
      hasKey: !!SUPABASE_KEY 
    })};
  }

  try {
    const res = await fetch(`${SUPABASE_URL}/rest/v1/shared_recipes?limit=1`, {
      headers: {
        "apikey": SUPABASE_KEY,
        "Authorization": `Bearer ${SUPABASE_KEY}`
      }
    });
    const text = await res.text();
    return { statusCode: 200, headers, body: JSON.stringify({
      status: res.status,
      keyPrefix: SUPABASE_KEY.substr(0, 20),
      response: text.substr(0, 300)
    })};
  } catch(e) {
    return { statusCode: 200, headers, body: JSON.stringify({ error: e.message }) };
  }
};
