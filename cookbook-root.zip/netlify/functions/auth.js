const crypto = require('crypto');
const SUPABASE_URL = process.env.SUPABASE_URL;
const SUPABASE_KEY = process.env.SUPABASE_SERVICE_KEY || process.env.SUPABASE_KEY;
const SECRET = process.env.AUTH_SECRET || 'rv-default-secret-change-me';

function hashPassword(password) {
  return crypto.createHmac('sha256', SECRET).update(password).digest('hex');
}

function makeToken(user) {
  const payload = Buffer.from(JSON.stringify({
    id: user.id, email: user.email, name: user.name,
    expires: Date.now() + 365 * 24 * 60 * 60 * 1000
  })).toString('base64url');
  const sig = crypto.createHmac('sha256', SECRET).update(payload).digest('base64url');
  return `${payload}.${sig}`;
}

function verifyToken(token) {
  try {
    const [payload, sig] = token.split('.');
    if (!payload || !sig) return null;
    const expected = crypto.createHmac('sha256', SECRET).update(payload).digest('base64url');
    if (sig !== expected) return null;
    const data = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8'));
    if (data.expires < Date.now()) return null;
    return data;
  } catch(e) { return null; }
}

async function sb(method, path, body) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1${path}`, {
    method,
    headers: {
      'apikey': SUPABASE_KEY,
      'Authorization': `Bearer ${SUPABASE_KEY}`,
      'Content-Type': 'application/json',
      'Prefer': method === 'POST' ? 'return=representation' : ''
    },
    body: body ? JSON.stringify(body) : undefined
  });
  const text = await res.text();
  console.log(`auth sb ${method} ${path} → ${res.status}: ${text.slice(0,200)}`);
  try { return { ok: res.ok, status: res.status, data: JSON.parse(text) }; }
  catch(e) { return { ok: res.ok, status: res.status, data: text }; }
}

async function sendResetEmail(email, code) {
  // Use Supabase edge function or just log it — we'll show the code in the app for now
  // In production you'd send via SendGrid/Resend etc.
  console.log(`Password reset code for ${email}: ${code}`);
  return true;
}

exports.handler = async function(event) {
  const headers = { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' };
  if (event.httpMethod === 'OPTIONS') return { statusCode: 200, headers };

  try {
    const body = JSON.parse(event.body || '{}');
    const { action, email, password, name, token, code, newPassword, incomeBracket, zip, favoriteStores } = body;
    const emailLow = (email || '').trim().toLowerCase();

    // ── SIGNUP ──────────────────────────────────────────────────
    if (action === 'signup') {
      if (!emailLow || !password) return err(headers, 'Email and password required.');

      // Check if user exists
      const existing = await sb('GET', `/app_users?email=eq.${encodeURIComponent(emailLow)}&limit=1`);
      if (existing.ok && Array.isArray(existing.data) && existing.data.length) {
        return err(headers, 'An account with this email already exists. Please sign in.');
      }

      const user = {
        id: 'u_' + Date.now(),
        email: emailLow,
        name: name || emailLow.split('@')[0],
        password_hash: hashPassword(password),
        income_bracket: incomeBracket || null,
        zip: zip || null,
        favorite_stores: favoriteStores || [],
        created_at: new Date().toISOString()
      };
      const r = await sb('POST', '/app_users', user);
      if (!r.ok) return err(headers, 'Could not create account: ' + JSON.stringify(r.data));

      const tok = makeToken(user);
      return ok(headers, { token: tok, user: { id: user.id, email: user.email, name: user.name, incomeBracket: user.income_bracket, zip: user.zip, favoriteStores: user.favorite_stores || [] } });
    }

    // ── LOGIN ────────────────────────────────────────────────────
    if (action === 'login') {
      if (!emailLow || !password) return err(headers, 'Email and password required.');

      const r = await sb('GET', `/app_users?email=eq.${encodeURIComponent(emailLow)}&limit=1`);
      if (!r.ok || !Array.isArray(r.data) || !r.data.length) {
        return err(headers, 'No account found with this email. Please sign up.');
      }
      const user = r.data[0];
      if (user.password_hash !== hashPassword(password)) {
        return err(headers, 'Incorrect password.');
      }
      const tok = makeToken(user);
      // Update last_seen_at
      await sb('PATCH', `/app_users?id=eq.${encodeURIComponent(user.id)}`, { last_seen_at: new Date().toISOString() });
      return ok(headers, { token: tok, user: { id: user.id, email: user.email, name: user.name, incomeBracket: user.income_bracket, zip: user.zip, favoriteStores: user.favorite_stores || [] } });
    }

    // ── FORGOT PASSWORD — send reset code ────────────────────────
    if (action === 'forgot') {
      if (!emailLow) return err(headers, 'Email required.');
      const r = await sb('GET', `/app_users?email=eq.${encodeURIComponent(emailLow)}&limit=1`);
      if (!r.ok || !Array.isArray(r.data) || !r.data.length) {
        // Don't reveal if account exists
        return ok(headers, { sent: true });
      }
      const resetCode = Math.floor(100000 + Math.random() * 900000).toString();
      const expires = new Date(Date.now() + 15 * 60 * 1000).toISOString(); // 15 min
      await sb('PATCH', `/app_users?email=eq.${encodeURIComponent(emailLow)}`, {
        reset_code: resetCode,
        reset_expires: expires
      });
      console.log(`RESET CODE for ${emailLow}: ${resetCode}`); // visible in Netlify logs
      return ok(headers, { sent: true, code: resetCode }); // return code directly for now
    }

    // ── RESET PASSWORD — verify code + set new password ──────────
    if (action === 'reset') {
      if (!emailLow || !code || !newPassword) return err(headers, 'Email, code, and new password required.');
      const r = await sb('GET', `/app_users?email=eq.${encodeURIComponent(emailLow)}&limit=1`);
      if (!r.ok || !Array.isArray(r.data) || !r.data.length) return err(headers, 'Account not found.');
      const user = r.data[0];
      if (user.reset_code !== code) return err(headers, 'Invalid reset code.');
      if (new Date(user.reset_expires) < new Date()) return err(headers, 'Reset code expired. Please request a new one.');
      await sb('PATCH', `/app_users?email=eq.${encodeURIComponent(emailLow)}`, {
        password_hash: hashPassword(newPassword),
        reset_code: null,
        reset_expires: null
      });
      const tok = makeToken(user);
      return ok(headers, { token: tok, user: { id: user.id, email: user.email, name: user.name } });
    }

    // ── VERIFY token ─────────────────────────────────────────────
    if (action === 'verify') {
      const data = verifyToken(token);
      if (!data) return err(headers, 'Invalid or expired token.', 401);
      return ok(headers, { user: { id: data.id, email: data.email, name: data.name } });
    }

    if (action === 'logout') return ok(headers, { ok: true });

    return err(headers, 'Unknown action.');
  } catch(e) {
    console.error('auth error:', e.message);
    return err(headers, e.message, 500);
  }
};

function ok(headers, body) { return { statusCode: 200, headers, body: JSON.stringify(body) }; }
function err(headers, msg, status) { return { statusCode: status || 400, headers, body: JSON.stringify({ error: msg }) }; }
