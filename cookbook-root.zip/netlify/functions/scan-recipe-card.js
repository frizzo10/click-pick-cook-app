exports.handler = async function(event) {
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers: { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'Content-Type' }, body: '' };
  }
  if (event.httpMethod !== 'POST') return { statusCode: 405, body: 'Method Not Allowed' };

  const KEY = process.env.ANTHROPIC_API_KEY;
  if (!KEY) return { statusCode: 500, headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }, body: JSON.stringify({ error: 'ANTHROPIC_API_KEY not set' }) };

  try {
    const { imageData, mediaType } = JSON.parse(event.body);
    if (!imageData) return { statusCode: 400, headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }, body: JSON.stringify({ error: 'No image provided' }) };

    const res = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-api-key': KEY, 'anthropic-version': '2023-06-01' },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 3000,
        system: `You are reading a handwritten or printed recipe card, cookbook page, or recipe note.
Extract the full recipe and return it as a single JSON object. No markdown, no backticks, no explanation — raw JSON only.

Format:
{
  "title": "Recipe name",
  "emoji": "one emoji that represents the dish",
  "cuisine": "e.g. Italian, American, French",
  "mealType": "Breakfast|Lunch|Dinner|Dessert|Snack|Appetizer",
  "time": "e.g. 45 min",
  "difficulty": "Easy|Medium|Hard",
  "description": "2 warm sentences describing the dish as if telling a friend about it",
  "ingredients": ["list", "of", "ingredients", "with", "quantities"],
  "instructions": ["Step 1 text", "Step 2 text", ...],
  "notes": "Any tips, variations, or personal notes found on the card, or empty string",
  "source": "e.g. Grandma's Recipe Box, Family Cookbook, etc. if identifiable from the card"
}

If handwriting is unclear, make your best interpretation. If the recipe is incomplete, fill in reasonable standard steps.
Always return valid JSON even if the card is hard to read.`,
        messages: [{
          role: 'user',
          content: [
            {
              type: 'image',
              source: { type: 'base64', media_type: mediaType || 'image/jpeg', data: imageData }
            },
            { type: 'text', text: 'Please read this recipe card and extract the full recipe.' }
          ]
        }]
      })
    });

    const data = await res.json();
    if (data.error) throw new Error(data.error.message || 'Vision failed');

    const raw = data.content.map(c => c.text || '').join('').replace(/```json|```/g, '').trim();
    let recipe;
    try { recipe = JSON.parse(raw); } catch(e) {
      throw new Error('Could not parse recipe from image. Please try a clearer photo.');
    }

    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
      body: JSON.stringify({ recipe })
    };

  } catch(e) {
    return {
      statusCode: 500,
      headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
      body: JSON.stringify({ error: e.message })
    };
  }
};
