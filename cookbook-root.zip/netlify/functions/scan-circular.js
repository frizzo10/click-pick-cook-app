exports.handler = async function (event) {
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers: { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'Content-Type' }, body: '' };
  }
  if (event.httpMethod !== 'POST') return { statusCode: 405, body: 'Method Not Allowed' };

  const KEY = process.env.ANTHROPIC_API_KEY;
  if (!KEY) return { statusCode: 500, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ error: 'ANTHROPIC_API_KEY not set' }) };

  try {
    const { imageData, mediaType, mode } = JSON.parse(event.body);
    if (!imageData) return { statusCode: 400, body: JSON.stringify({ error: 'No image data provided' }) };

    // ── Step 1: Extract sale items from circular image ────────────────────────
    const extractRes = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-api-key': KEY, 'anthropic-version': '2023-06-01' },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 1024,
        system: `You are reading a grocery store weekly sale circular or advertisement. 
Extract ONLY center-of-plate items that appear to be on sale — proteins, poultry, seafood, cuts of meat, fresh fish, and produce suitable as a main dish ingredient (e.g. salmon, chicken breast, ground beef, shrimp, pork chops, lamb, steak, whole fish, large vegetables like butternut squash or eggplant).

IGNORE: frozen meals, snacks, beverages, paper goods, dairy, cereal, canned goods, condiments, cleaning supplies.

Return ONLY a raw JSON array, no markdown, no backticks, no explanation.
Format: [{"item":"Chicken Breast","price":"$2.99/lb","unit":"per lb","emoji":"🍗"},...]

If you cannot read prices clearly, still return the food items you can identify with price as "sale price".
If you find no center-of-plate items at all, return an empty array: []
Extract up to 8 items maximum.`,
        messages: [{
          role: 'user',
          content: [
            {
              type: 'image',
              source: { type: 'base64', media_type: mediaType || 'image/jpeg', data: imageData }
            },
            { type: 'text', text: 'Extract the center-of-plate sale items from this grocery circular.' }
          ]
        }]
      })
    });

    const extractData = await extractRes.json();
    if (extractData.error) throw new Error(extractData.error.message || 'Vision extraction failed');

    const raw = extractData.content.map(c => c.text || '').join('').replace(/```json|```/g, '').trim();
    let items = [];
    try { items = JSON.parse(raw); } catch(e) { items = []; }

    if (!items || items.length === 0) {
      return {
        statusCode: 200,
        headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
        body: JSON.stringify({ items: [], recipes: [], message: 'No center-of-plate sale items found in this image. Try a clearer photo of the meat, seafood, or produce section.' })
      };
    }

    // ── Step 2: Generate recipes from extracted items ─────────────────────────
    const itemList = items.map(i => `${i.item}${i.price ? ' (' + i.price + ')' : ''}`).join(', ');

    const recipeRes = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-api-key': KEY, 'anthropic-version': '2023-06-01' },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 2500,
        system: `You are a world-class chef. Given a list of sale items from a grocery circular, create 3 delicious dinner recipes that feature one or more of these items as the star of the plate.

Respond ONLY with a raw JSON array, no markdown, no backticks.
Each recipe: { title, emoji (1 emoji), cuisine, mealType, time, difficulty (Easy/Medium/Hard), description (2 sentences highlighting the sale item), ingredients (string[]), instructions (string[]), notes, saleItem (the featured sale item name), salePrice (the price if available) }`,
        messages: [{
          role: 'user',
          content: `These items are on sale this week at my local grocery store: ${itemList}. Create 3 dinner recipes that make these sale items the star of the meal.`
        }]
      })
    });

    const recipeData = await recipeRes.json();
    if (recipeData.error) throw new Error(recipeData.error.message || 'Recipe generation failed');

    const recipeRaw = recipeData.content.map(c => c.text || '').join('').replace(/```json|```/g, '').trim();
    let recipes = [];
    try { recipes = JSON.parse(recipeRaw); } catch(e) { recipes = []; }

    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
      body: JSON.stringify({ items, recipes })
    };

  } catch (e) {
    return {
      statusCode: 500,
      headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
      body: JSON.stringify({ error: e.message })
    };
  }
};
