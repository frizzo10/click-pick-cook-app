const crypto = require('crypto');
const SUPABASE_URL = process.env.SUPABASE_URL;
const SUPABASE_KEY = process.env.SUPABASE_SERVICE_KEY || process.env.SUPABASE_KEY;
const SECRET = process.env.AUTH_SECRET || 'rv-default-secret-change-me';

const headers = {
  'Content-Type': 'application/json',
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type'
};

function verifyToken(token) {
  try {
    const [payload, sig] = token.split('.');
    if (!payload || !sig) return null;
    const expected = crypto.createHmac('sha256', SECRET).update(payload).digest('base64url');
    if (sig !== expected) return null;
    const data = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8'));
    if (data.expires < Date.now()) return null;
    return data;
  } catch(e) { return null; }
}

async function sb(method, path, body) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${path}`, {
    method,
    headers: {
      'apikey': SUPABASE_KEY,
      'Authorization': `Bearer ${SUPABASE_KEY}`,
      'Content-Type': 'application/json',
      'Prefer': method === 'POST' ? 'return=representation,resolution=merge-duplicates' : 'return=representation'
    },
    body: body ? JSON.stringify(body) : undefined
  });
  const text = await res.text();
  console.log(`sb ${method} ${path} → ${res.status}: ${text.slice(0,200)}`);
  try { return { ok: res.ok, status: res.status, data: JSON.parse(text) }; }
  catch(e) { return { ok: res.ok, status: res.status, data: text }; }
}

exports.handler = async function(event) {
  if (event.httpMethod === 'OPTIONS') return { statusCode: 200, headers, body: '' };
  if (event.httpMethod !== 'POST') return { statusCode: 405, headers, body: JSON.stringify({ error: 'POST only' }) };

  let body;
  try { body = JSON.parse(event.body || '{}'); }
  catch(e) { return { statusCode: 400, headers, body: JSON.stringify({ error: 'Invalid JSON' }) }; }

  const { action, token, userId } = body;
  if (!token || !userId) return { statusCode: 401, headers, body: JSON.stringify({ error: 'Auth required' }) };

  const user = verifyToken(token);
  if (!user || user.id !== userId) {
    console.log('Token verify failed for userId:', userId);
    return { statusCode: 401, headers, body: JSON.stringify({ error: 'Invalid token' }) };
  }

  // ── PUSH ──────────────────────────────────────────────────────
  if (action === 'push') {
    const { saved, books } = body;
    const cleanSaved = (saved || []).map(function(r) {
      const c = Object.assign({}, r);
      delete c.photo;
      delete c.photos;
      delete c._hasPhotos;
      return c;
    });

    console.log(`Pushing ${cleanSaved.length} recipes, ${(books||[]).length} books for ${userId}`);

    // Upsert via POST with merge-duplicates
    const r = await sb('POST', 'user_data', {
      user_id: userId,
      saved: cleanSaved,
      books: books || [],
      updated_at: new Date().toISOString()
    });

    if (!r.ok) {
      // Fallback to PATCH
      const r2 = await sb('PATCH', `user_data?user_id=eq.${encodeURIComponent(userId)}`, {
        saved: cleanSaved,
        books: books || [],
        updated_at: new Date().toISOString()
      });
      if (!r2.ok) {
        console.error('Push failed:', JSON.stringify(r2.data));
        return { statusCode: 500, headers, body: JSON.stringify({ error: 'Save failed', detail: r2.data }) };
      }
    }

    return { statusCode: 200, headers, body: JSON.stringify({ ok: true, savedCount: cleanSaved.length }) };
  }

  // ── PULL ──────────────────────────────────────────────────────
  if (action === 'pull') {
    const r = await sb('GET', `user_data?user_id=eq.${encodeURIComponent(userId)}&select=saved,books,updated_at`);
    if (!r.ok || !Array.isArray(r.data) || !r.data.length) {
      return { statusCode: 200, headers, body: JSON.stringify({ saved: [], books: [], fresh: false }) };
    }
    const row = r.data[0];
    console.log(`Pulled ${(row.saved||[]).length} recipes for ${userId}`);
    return { statusCode: 200, headers, body: JSON.stringify({
      saved: row.saved || [],
      books: row.books || [],
      updatedAt: row.updated_at,
      fresh: true
    })};
  }

  return { statusCode: 400, headers, body: JSON.stringify({ error: 'Unknown action' }) };
};
