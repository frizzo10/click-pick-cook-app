const SUPABASE_URL = process.env.SUPABASE_URL;
const SUPABASE_KEY = process.env.SUPABASE_SERVICE_KEY || process.env.SUPABASE_KEY;

exports.handler = async function(event) {
  const headers = { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" };
  if (event.httpMethod === "OPTIONS") return { statusCode: 200, headers };

  try {
    const { photoBase64, fileName } = JSON.parse(event.body);

    // Handle both base64 data URLs and plain https:// URLs
    if (photoBase64.startsWith('http://') || photoBase64.startsWith('https://')) {
      // Already a URL — just return it directly
      console.log('Photo is already a URL, returning as-is:', photoBase64.slice(0, 80));
      return { statusCode: 200, headers, body: JSON.stringify({ url: photoBase64 }) };
    }

    const base64Data = photoBase64.replace(/^data:image\/\w+;base64,/, '');
    const buffer = Buffer.from(base64Data, 'base64');
    const mimeType = photoBase64.match(/^data:(image\/\w+);base64,/)?.[1] || 'image/jpeg';

    console.log(`Uploading ${fileName} (${buffer.length} bytes) to Supabase Storage`);

    const res = await fetch(`${SUPABASE_URL}/storage/v1/object/recipe-photos/${fileName}`, {
      method: 'POST',
      headers: {
        'apikey': SUPABASE_KEY,
        'Authorization': `Bearer ${SUPABASE_KEY}`,
        'Content-Type': mimeType,
        'x-upsert': 'true'
      },
      body: buffer
    });

    const text = await res.text();
    console.log(`Storage upload → ${res.status}: ${text.slice(0, 200)}`);

    let data;
    try { data = JSON.parse(text); } catch(e) { data = { error: text }; }
    if (res.status >= 400) throw new Error(`Storage error ${res.status}: ${text.slice(0,200)}`);

    const publicUrl = `${SUPABASE_URL}/storage/v1/object/public/recipe-photos/${fileName}`;
    console.log('Upload success, public URL:', publicUrl);
    return { statusCode: 200, headers, body: JSON.stringify({ url: publicUrl }) };

  } catch(e) {
    console.error('upload-photo error:', e.message);
    return { statusCode: 500, headers, body: JSON.stringify({ error: e.message }) };
  }
};
