const SUPABASE_URL = process.env.SUPABASE_URL;
const SUPABASE_KEY = process.env.SUPABASE_SERVICE_KEY;

async function supabase(method, path, body) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1${path}`, {
    method,
    headers: {
      "Content-Type": "application/json",
      "apikey": SUPABASE_KEY,
      "Authorization": `Bearer ${SUPABASE_KEY}`,
      "Prefer": method === "POST" ? "return=representation" : ""
    },
    body: body ? JSON.stringify(body) : undefined
  });
  const text = await res.text();
  try { return JSON.parse(text); } catch(e) { return { error: text }; }
}

function makeId() {
  return 'cb_' + Math.random().toString(36).substr(2,5) + Date.now().toString(36).substr(-4);
}

exports.handler = async function(event) {
  const headers = { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" };
  if (event.httpMethod === "OPTIONS") return { statusCode: 200, headers };

  if (!SUPABASE_URL || !SUPABASE_KEY) {
    return { statusCode: 500, headers, body: JSON.stringify({ error: "Missing env vars" }) };
  }

  try {
    if (event.httpMethod === "POST") {
      const body = JSON.parse(event.body);
      const id = makeId();
      const row = {
        id,
        recipe: body.cookbook, // reuse same table, store cookbook object
        background_id: 'cookbook',
        message: body.message || "",
        sender_name: body.senderName || "",
        created_at: new Date().toISOString()
      };
      const result = await supabase("POST", "/shared_recipes", row);
      if (result && result.error) throw new Error(typeof result.error === 'object' ? result.error.message : result.error);
      const siteUrl = body.siteUrl || "https://celadon-duckanoo-753d58.netlify.app";
      return { statusCode: 200, headers, body: JSON.stringify({ url: `${siteUrl}/cookbook-share.html?id=${id}` }) };
    }

    if (event.httpMethod === "GET") {
      const id = event.queryStringParameters && event.queryStringParameters.id;
      if (!id) return { statusCode: 400, headers, body: JSON.stringify({ error: "Missing id" }) };
      const result = await supabase("GET", `/shared_recipes?id=eq.${id}&limit=1`);
      if (!result || !result[0]) return { statusCode: 404, headers, body: JSON.stringify({ error: "Not found" }) };
      return { statusCode: 200, headers, body: JSON.stringify({ cookbook: result[0].recipe, message: result[0].message, senderName: result[0].sender_name }) };
    }

    return { statusCode: 405, headers, body: JSON.stringify({ error: "Method not allowed" }) };
  } catch(e) {
    return { statusCode: 500, headers, body: JSON.stringify({ error: e.message }) };
  }
};
