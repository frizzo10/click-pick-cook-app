/**
 * Weekly Circular — Kroger API Integration
 *
 * GET /.netlify/functions/circular?zip=90210
 * GET /.netlify/functions/circular?zip=90210&locationId=01400413
 * GET /.netlify/functions/circular?zip=90210&action=stores   ← list nearby Kroger stores
 *
 * Register at: https://developer.kroger.com/manage/apps
 * Required env vars in Netlify:
 *   KROGER_CLIENT_ID
 *   KROGER_CLIENT_SECRET
 */

const KROGER_CLIENT_ID     = process.env.KROGER_CLIENT_ID;
const KROGER_CLIENT_SECRET = process.env.KROGER_CLIENT_SECRET;
const KROGER_BASE          = 'https://api.kroger.com/v1';

const CORS = {
  'Content-Type': 'application/json',
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, OPTIONS'
};

// ── Token cache (lives for warm Lambda instance) ──────────────────────────────
let _tok = { token: null, exp: 0 };

async function getToken() {
  if (_tok.token && Date.now() < _tok.exp - 60000) return _tok.token;
  const creds = Buffer.from(`${KROGER_CLIENT_ID}:${KROGER_CLIENT_SECRET}`).toString('base64');
  const res = await fetch(`${KROGER_BASE}/connect/oauth2/token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'Authorization': `Basic ${creds}` },
    body: 'grant_type=client_credentials&scope=product.compact'
  });
  if (!res.ok) throw new Error(`Kroger auth ${res.status}: ${await res.text()}`);
  const d = await res.json();
  _tok = { token: d.access_token, exp: Date.now() + (d.expires_in || 1800) * 1000 };
  return _tok.token;
}

// ── Stores near ZIP ───────────────────────────────────────────────────────────
async function findStores(zip, token) {
  const res = await fetch(
    `${KROGER_BASE}/locations?filter.zipCode.near=${zip}&filter.radiusInMiles=15&filter.limit=8`,
    { headers: { 'Authorization': `Bearer ${token}`, 'Accept': 'application/json' } }
  );
  if (!res.ok) throw new Error(`Locations ${res.status}`);
  const data = await res.json();
  return (data.data || []).map(loc => ({
    locationId: loc.locationId,
    name:  loc.name || loc.chain,
    chain: loc.chain,
    address: loc.address ? [loc.address.addressLine1, loc.address.city, loc.address.state].filter(Boolean).join(', ') : '',
    phone: loc.phone || ''
  }));
}

// ── Products on sale ──────────────────────────────────────────────────────────
const SEARCH_TERMS = [
  'chicken','beef','pork','salmon','shrimp','turkey',
  'broccoli','tomato','spinach','potato','apple','strawberry','avocado','pepper',
  'milk','cheese','yogurt','eggs','butter',
  'bread','pasta','rice','cereal','soup','olive oil',
  'orange juice','coffee','frozen pizza'
];

function shuffle(a) {
  const b = [...a];
  for (let i = b.length-1; i > 0; i--) {
    const j = Math.floor(Math.random()*(i+1));
    [b[i],b[j]] = [b[j],b[i]];
  }
  return b;
}

async function fetchDeals(locationId, token) {
  const terms = shuffle(SEARCH_TERMS).slice(0, 12);
  const deals = [];
  const seen  = new Set();

  for (let i = 0; i < terms.length; i += 4) {
    const batch = terms.slice(i, i+4);
    const results = await Promise.all(batch.map(t => fetchTerm(t, locationId, token)));
    for (const items of results) {
      for (const item of items) {
        if (!seen.has(item.id)) { seen.add(item.id); deals.push(item); }
      }
    }
    if (deals.length >= 30) break;
  }
  return deals;
}

async function fetchTerm(term, locationId, token) {
  try {
    const url = `${KROGER_BASE}/products?filter.term=${encodeURIComponent(term)}&filter.locationId=${locationId}&filter.limit=10`;
    const res = await fetch(url, { headers: { 'Authorization': `Bearer ${token}`, 'Accept': 'application/json' } });
    if (!res.ok) return [];
    const data = await res.json();
    return (data.data || []).filter(p => isOnSale(p)).map(p => normalise(p));
  } catch(e) {
    console.error(`fetchTerm "${term}":`, e.message);
    return [];
  }
}

function isOnSale(p) {
  const price = (((p.items||[])[0])||{}).price || {};
  return price.promo && price.promo > 0 && price.promo < price.regular;
}

function normalise(p) {
  const item  = (p.items||[])[0] || {};
  const price = item.price || {};
  const reg   = price.regular || 0;
  const promo = price.promo   || 0;
  const pct   = reg ? Math.round((1 - promo/reg)*100) : 0;
  const savings = pct >= 5 ? `${pct}% OFF` : `$${(reg-promo).toFixed(2)} OFF`;
  const uom   = item.soldBy === 'WEIGHT' ? '/lb' : '';
  const name  = toTitle(p.description || 'Sale Item');

  return {
    id:           p.productId,
    name,
    category:     guessCategory(name, p.categories),
    price:        `$${promo.toFixed(2)}${uom}`,
    regularPrice: `$${reg.toFixed(2)}${uom}`,
    savings,
    emoji:        getEmoji(name),
    desc:         item.size || '',
    brand:        p.brand  || '',
    validUntil:   'This week only',
    imageUrl:     getImg(p)
  };
}

function getImg(p) {
  for (const img of (p.images||[])) {
    if (img.perspective==='front') {
      for (const s of (img.sizes||[])) if (s.size==='medium') return s.url;
      if ((img.sizes||[]).length) return img.sizes[0].url;
    }
  }
  const first = (p.images||[])[0];
  return first && (first.sizes||[]).length ? first.sizes[0].url : null;
}

function guessCategory(name, cats) {
  if (cats && cats.length) {
    const c = cats[0].toLowerCase();
    if (/meat|poultry|seafood/.test(c))      return 'Meat & Seafood';
    if (/produce|vegetable|fruit/.test(c))   return 'Produce';
    if (/dairy|egg/.test(c))                  return 'Dairy & Eggs';
    if (/bakery|bread/.test(c))              return 'Bakery';
    if (/beverage|drink|juice/.test(c))      return 'Beverages';
    if (/frozen/.test(c))                    return 'Frozen';
    if (/deli/.test(c))                      return 'Deli';
  }
  const n = name.toLowerCase();
  if (/chicken|beef|pork|steak|lamb|turkey|salmon|shrimp|tilapia|tuna|fish|crab/.test(n)) return 'Meat & Seafood';
  if (/apple|banana|berry|tomato|potato|onion|pepper|lettuce|spinach|broccoli|carrot|corn|avocado|mango|peach|grape/.test(n)) return 'Produce';
  if (/milk|cheese|yogurt|butter|cream|egg/.test(n))  return 'Dairy & Eggs';
  if (/bread|bagel|muffin|cake|cookie|roll/.test(n))  return 'Bakery';
  if (/juice|soda|coffee|tea|water|beer|wine/.test(n)) return 'Beverages';
  return 'Pantry';
}

function getEmoji(n) {
  n = n.toLowerCase();
  if (n.includes('chicken'))                        return '🍗';
  if (/beef|steak|ground/.test(n))                  return '🥩';
  if (/pork|bacon|ham/.test(n))                     return '🥓';
  if (/salmon|fish|tilapia|tuna/.test(n))           return '🐟';
  if (/shrimp|lobster|crab/.test(n))                return '🦐';
  if (n.includes('tomato'))                         return '🍅';
  if (n.includes('broccoli'))                       return '🥦';
  if (/spinach|lettuce|kale/.test(n))               return '🥬';
  if (n.includes('apple'))                          return '🍎';
  if (n.includes('banana'))                         return '🍌';
  if (/berry|strawberry/.test(n))                   return '🍓';
  if (n.includes('avocado'))                        return '🥑';
  if (n.includes('corn'))                           return '🌽';
  if (n.includes('pepper'))                         return '🫑';
  if (n.includes('carrot'))                         return '🥕';
  if (n.includes('potato'))                         return '🥔';
  if (/onion|garlic/.test(n))                       return '🧅';
  if (n.includes('milk'))                           return '🥛';
  if (n.includes('cheese'))                         return '🧀';
  if (n.includes('egg'))                            return '🥚';
  if (/butter|cream/.test(n))                       return '🧈';
  if (n.includes('yogurt'))                         return '🥛';
  if (/bread|bagel|bun/.test(n))                   return '🍞';
  if (/pasta|spaghetti|penne|noodle/.test(n))       return '🍝';
  if (n.includes('rice'))                           return '🍚';
  if (n.includes('soup'))                           return '🍲';
  if (/juice|lemonade/.test(n))                     return '🍊';
  if (n.includes('coffee'))                         return '☕';
  if (n.includes('water'))                          return '💧';
  if (/oil|olive/.test(n))                          return '🫙';
  if (/pizza|frozen/.test(n))                       return '🍕';
  return '🏷';
}

function toTitle(s) {
  return s.toLowerCase().replace(/\b\w/g, c => c.toUpperCase());
}

// ── Handler ───────────────────────────────────────────────────────────────────
exports.handler = async function(event) {
  if (event.httpMethod === 'OPTIONS') return { statusCode: 200, headers: CORS, body: '' };

  const qs         = event.queryStringParameters || {};
  const zip        = (qs.zip || '').trim();
  const locationId = (qs.locationId || '').trim();
  const action     = (qs.action || '').trim();

  if (!zip) return { statusCode: 400, headers: CORS, body: JSON.stringify({ error: 'zip required' }) };

  // No credentials → mock
  if (!KROGER_CLIENT_ID || !KROGER_CLIENT_SECRET) {
    console.warn('Kroger credentials not set — returning mock data');
    return { statusCode: 200, headers: CORS, body: JSON.stringify(mockResponse(zip)) };
  }

  try {
    const token = await getToken();

    // action=stores → return store list for the store-picker UI
    if (action === 'stores') {
      const stores = await findStores(zip, token);
      return { statusCode: 200, headers: CORS, body: JSON.stringify({ stores }) };
    }

    // Resolve locationId
    let storeId = locationId, storeName = 'Kroger', chain = 'KROGER';
    if (!storeId) {
      const stores = await findStores(zip, token);
      if (!stores.length) {
        return { statusCode: 200, headers: CORS, body: JSON.stringify({
          ...mockResponse(zip),
          notice: `No Kroger-family store found near ${zip}. Showing sample deals.`
        })};
      }
      storeId   = stores[0].locationId;
      storeName = stores[0].name;
      chain     = stores[0].chain;
    }

    const deals = await fetchDeals(storeId, token);

    return { statusCode: 200, headers: CORS, body: JSON.stringify({
      deals, storeName, chain, locationId: storeId, zip,
      source: 'kroger', mock: false, updatedAt: new Date().toISOString()
    })};

  } catch(e) {
    console.error('Kroger error:', e.message);
    return { statusCode: 200, headers: CORS, body: JSON.stringify({
      ...mockResponse(zip),
      notice: 'Live data temporarily unavailable.',
      error: e.message
    })};
  }
};

// ── Mock fallback ─────────────────────────────────────────────────────────────
function mockResponse(zip) {
  return {
    deals: [
      { id:'d1',  name:'Boneless Chicken Breast', category:'Meat & Seafood', price:'$2.99/lb',   regularPrice:'$5.99/lb',   savings:'50% OFF',   emoji:'🍗', desc:'Fresh, never frozen.',        validUntil:'This week only' },
      { id:'d2',  name:'Atlantic Salmon Fillet',  category:'Meat & Seafood', price:'$7.99/lb',   regularPrice:'$12.99/lb',  savings:'38% OFF',   emoji:'🐟', desc:'Wild-caught.',               validUntil:'This week only' },
      { id:'d3',  name:'Ground Beef 80/20',        category:'Meat & Seafood', price:'$3.99/lb',   regularPrice:'$6.49/lb',   savings:'$2.50 OFF', emoji:'🥩', desc:'USDA Choice.',               validUntil:'This week only' },
      { id:'d4',  name:'Roma Tomatoes',            category:'Produce',        price:'$0.79/lb',   regularPrice:'$1.49/lb',   savings:'47% OFF',   emoji:'🍅', desc:'Firm and flavourful.',        validUntil:'This week only' },
      { id:'d5',  name:'Fresh Broccoli',           category:'Produce',        price:'$0.99/head', regularPrice:'$1.99/head', savings:'$1 OFF',    emoji:'🥦', desc:'Large heads.',               validUntil:'This week only' },
      { id:'d6',  name:'Organic Baby Spinach',     category:'Produce',        price:'$3.49',      regularPrice:'$5.99',      savings:'42% OFF',   emoji:'🥬', desc:'5oz bag.',                   validUntil:'This week only' },
      { id:'d7',  name:'Russet Potatoes',          category:'Produce',        price:'$2.99/5lb',  regularPrice:'$4.99/5lb',  savings:'$2 OFF',    emoji:'🥔', desc:'5lb bag.',                   validUntil:'This week only' },
      { id:'d8',  name:'Penne Pasta',              category:'Pantry',         price:'$0.99',      regularPrice:'$1.79',      savings:'45% OFF',   emoji:'🍝', desc:'16oz.',                      validUntil:'This week only' },
      { id:'d9',  name:'Extra Virgin Olive Oil',   category:'Pantry',         price:'$5.99',      regularPrice:'$9.99',      savings:'$4 OFF',    emoji:'🫙', desc:'16.9 fl oz.',                validUntil:'This week only' },
      { id:'d10', name:'Greek Yogurt Plain',       category:'Dairy & Eggs',   price:'$1.99',      regularPrice:'$3.49',      savings:'43% OFF',   emoji:'🥛', desc:'32oz.',                      validUntil:'This week only' },
      { id:'d11', name:'Shredded Mozzarella',      category:'Dairy & Eggs',   price:'$2.49',      regularPrice:'$4.29',      savings:'$1.80 OFF', emoji:'🧀', desc:'16oz.',                      validUntil:'This week only' },
      { id:'d12', name:'Large Eggs',               category:'Dairy & Eggs',   price:'$2.99/doz',  regularPrice:'$4.99/doz',  savings:'$2 OFF',    emoji:'🥚', desc:'Grade A, free range.',        validUntil:'This week only' },
      { id:'d13', name:'Sourdough Bread',          category:'Bakery',         price:'$2.49',      regularPrice:'$4.49',      savings:'$2 OFF',    emoji:'🍞', desc:'Freshly baked.',             validUntil:'This week only' },
      { id:'d14', name:'Orange Juice',             category:'Beverages',      price:'$3.49',      regularPrice:'$5.99',      savings:'42% OFF',   emoji:'🍊', desc:'52oz, not from concentrate.', validUntil:'This week only' },
    ],
    storeName: 'Sample Store', zip, source: 'mock', mock: true
  };
}
