// Uses Pexels API for accurate food photography

exports.handler = async function(event) {
  if (event.httpMethod === 'OPTIONS') return { statusCode: 200, headers: cors(), body: '' };
  if (event.httpMethod !== 'POST') return { statusCode: 405, body: 'Method Not Allowed' };

  const PEXELS_KEY = process.env.PEXELS_API_KEY;
  if (!PEXELS_KEY) return ok({ url: null, error: 'PEXELS_API_KEY not set' });

  try {
    const { photoSearch, title, cuisine, mealType } = JSON.parse(event.body || '{}');

    const stopWords = new Set(['with','and','or','the','a','an','in','on','of','for','to','from','style','inspired','classic','traditional','homemade','fresh','easy','simple','creamy','crispy','spicy','sweet','savory']);
    const raw = photoSearch || title || '';
    const words = raw.split(/\s+/).filter(w => w.length > 2 && !stopWords.has(w.toLowerCase()));

    const queries = [
      words.slice(0, 3).join(' '),
      words.slice(0, 2).join(' '),
      words[0],
      cuisine,
      mealType || 'food',
    ].map(q => (q || '').trim()).filter(Boolean).filter((q, i, a) => a.indexOf(q) === i);

    for (const q of queries) {
      try {
        const res = await fetch(
          `https://api.pexels.com/v1/search?query=${encodeURIComponent(q + ' food')}&per_page=5&orientation=landscape`,
          { headers: { Authorization: PEXELS_KEY } }
        );
        const data = await res.json();
        const photo = data?.photos?.[0];
        if (photo) {
          return ok({ url: photo.src.large || photo.src.original, photographer: photo.photographer });
        }
      } catch(e) { /* try next query */ }
    }

    return ok({ url: null });

  } catch(e) {
    return ok({ url: null, error: e.message });
  }
};

function cors() {
  return { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' };
}
function ok(body) {
  return { statusCode: 200, headers: cors(), body: JSON.stringify(body) };
}
