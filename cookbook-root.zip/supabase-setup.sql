-- Run this in Supabase → SQL Editor → New Query

create table shared_recipes (
  id text primary key,
  recipe jsonb not null,
  background_id text,
  message text,
  sender_name text,
  created_at timestamptz default now()
);

-- Allow anyone to read and insert (no login needed)
alter table shared_recipes enable row level security;

create policy "Anyone can insert" on shared_recipes
  for insert with check (true);

create policy "Anyone can read" on shared_recipes
  for select using (true);

-- Storage policies for recipe-photos bucket
-- Run this in Supabase → SQL Editor

insert into storage.buckets (id, name, public) 
values ('recipe-photos', 'recipe-photos', true)
on conflict (id) do update set public = true;

create policy "Anyone can upload photos" on storage.objects
  for insert with check (bucket_id = 'recipe-photos');

create policy "Anyone can view photos" on storage.objects
  for select using (bucket_id = 'recipe-photos');

-- Coupons table
CREATE TABLE IF NOT EXISTS coupons (
  id text PRIMARY KEY,
  data jsonb NOT NULL,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE coupons ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public read" ON coupons FOR SELECT USING (true);
CREATE POLICY "Service insert" ON coupons FOR INSERT WITH CHECK (true);


-- Suggestions table
CREATE TABLE IF NOT EXISTS suggestions (
  id text PRIMARY KEY,
  data jsonb NOT NULL,
  active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE suggestions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public read" ON suggestions FOR SELECT USING (true);
CREATE POLICY "Service insert" ON suggestions FOR INSERT WITH CHECK (true);


-- Loyalty stores table (one row per grocery store)
CREATE TABLE IF NOT EXISTS loyalty_stores (
  id text PRIMARY KEY,
  name text NOT NULL,
  api_key_hash text NOT NULL UNIQUE,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE loyalty_stores ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Service only" ON loyalty_stores USING (false);

-- Loyalty segments table (hashed phone + tags, no PII)
CREATE TABLE IF NOT EXISTS loyalty_segments (
  phone_hash text NOT NULL,
  store_id text NOT NULL,
  store_name text,
  tags text[] NOT NULL DEFAULT '{}',
  updated_at timestamptz DEFAULT now(),
  PRIMARY KEY (phone_hash, store_id)
);
ALTER TABLE loyalty_segments ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Service only" ON loyalty_segments USING (false);


-- User data sync table
CREATE TABLE IF NOT EXISTS user_data (
  user_id text PRIMARY KEY,
  saved jsonb NOT NULL DEFAULT '[]',
  books jsonb NOT NULL DEFAULT '[]',
  updated_at timestamptz DEFAULT now()
);
ALTER TABLE user_data ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Service only" ON user_data USING (false);


-- App users table (replaces stateless auth)
CREATE TABLE IF NOT EXISTS app_users (
  id text PRIMARY KEY,
  email text UNIQUE NOT NULL,
  name text,
  password_hash text NOT NULL,
  reset_code text,
  reset_expires timestamptz,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE app_users ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Service only" ON app_users USING (false);
